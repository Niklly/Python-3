media = float(input("Digite a média do aluno: "))
if media >= 9.0:
    print("A")
else:
    if media >= 8.0:
        print("B")
    else:
        if media >= 7.0:
            print("C")
        else:
            if media >= 6.0:
                print("D")
            else:
                print("R")