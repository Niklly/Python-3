contaPar = 0
somaPar = 0
x = int(input("Digite um numero: "))
if x%2 == 0:
	contaPar += 1 #contPar = contPar + 1
	somaPar += x #somaPar = somaPar + x
x = int(input("Digite um numero: "))
if x%2 == 0:
	contaPar += 1 
	somaPar += x
x = int(input("Digite um numero: "))
if x%2 == 0:
	contaPar += 1
	somaPar += x
x = int(input("Digite um numero: "))
if x%2 == 0:
	contaPar += 1
	somaPar += x
print(f"Foram digitados {contaPar} números pares")
print(f"Soma dos números pares: {somaPar}")  
if contaPar > 0:
	print(f"Média dos números pares: {somaPar/contaPar:.2f}") # :.2f -> para imprimir com duas casas decimais